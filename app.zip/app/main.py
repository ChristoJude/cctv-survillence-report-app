# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 21:13:33 2023

@author: chris
"""

import cv2
import requests
import numpy as np
import imutils
import datetime
import os

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.camera import Camera
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock

# load pre-trained Haar Cascade classifier for face detection
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# create folder to save captured frames
if not os.path.exists('captured_frames'):
    os.makedirs('captured_frames')


class CameraApp(App):

    def build(self):
        self.url = "http://192.168.1.4:8080/video"
        self.response = requests.get(self.url, stream=True)
        self.camera = self.create_camera()
        self.button = Button(text='Exit', size_hint=(0.1, 0.1))
        self.button.bind(on_press=self.exit_app)
        layout = BoxLayout()
        layout.add_widget(self.camera)
        layout.add_widget(self.button)
        self.capture = cv2.VideoCapture(self.url)
        Clock.schedule_interval(self.update, 1.0 / 33.0)
        return layout

    def create_camera(self):
        camera = Camera(resolution=(1280, 720), play=True)
        camera.keep_ratio = False
        camera.allow_stretch = True
        return camera

    def update(self, dt):
        # read frame from video capture object
        ret, frame = self.capture.read()
        if ret:
            # resize frame for faster processing
            frame = imutils.resize(frame, width=1280)

            # convert frame to grayscale for face detection
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # detect faces using the Haar Cascade classifier
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cv2.putText(frame, timestamp, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            # loop over the faces and draw rectangles around them
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # capture and save the frame with timestamp
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"captured_frames/frame_{timestamp}.jpg"
                cv2.imwrite(filename, frame)

            # display the frame with face detection overlay
            buf1 = cv2.flip(frame, 1)
            buf = buf1.tobytes()
            texture = self.camera.texture
            texture.blit_buffer(buf, colorfmt='bgr', bufferfmt='ubyte')
            self.camera.canvas.ask_update()

        else:
            print("Failed to capture frame.")

    def exit_app(self, instance):
        self.capture.release()
        App.get_running_app().stop()


if __name__ == '__main__':
    CameraApp().run()
