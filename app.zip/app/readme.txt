to open this file on mit app inventor 

visit: http://ai2.appinventor.mit.edu/#5003555432693760
and open the PENALTY_PAYMENT.aia file on mit app inventor
